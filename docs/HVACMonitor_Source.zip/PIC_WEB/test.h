// test lcd segment
unsigned char TestExt(void);












