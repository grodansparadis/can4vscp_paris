// lcd_test.c
#if defined(HI_TECH_C)
	#include <pic18.h>
#else
	#include <p18cxxx.h>
#endif

#include "test.h" 

#define DELAY_TIME 			300
#define DT 					150
#define	DELAY_TIME_LONG		2000
#define	BIT2	0x04

volatile unsigned char mask_port_a 	= 0x3C&(~BIT2); // pull up BIT2
volatile unsigned char mask_port_b 	= 0x00;
volatile unsigned char mask_port_c 	= 0x04;
volatile unsigned char mask_port_d 	= 0xDF;
volatile unsigned char mask_port_e 	= 0x07;


volatile unsigned char temp_porta 	= 0x0;
volatile unsigned char temp_portb 	= 0x0;
volatile unsigned char temp_portc 	= 0x0;
volatile unsigned char temp_portd 	= 0x0; 
volatile unsigned char temp_porte 	= 0x0; 


unsigned char 	i		= 0;

// simple delay ~ 1 mS
void Delay(unsigned long a) { 
	 a *= 370;
	while (--a!=0); 
}

void InitPort(void) {

	// all as input
	ADCON1 	= 0x06;
	TRISA 	= 0xFF;
	TRISC 	= 0xFF;
	TRISB 	= 0xFF;
	TRISD 	= 0xFF;
	TRISE 	= 0x07;

	//pull up - output
	TRISA &= ~BIT2;
	//pull up - high
	PORTA |= BIT2;

	Delay(10);

}

void GetPort_AND(void) {

	temp_porta 	= PORTA;
	temp_porta 	&= mask_port_a; 
	temp_portb 	= PORTB;
	temp_portb 	&= mask_port_b; 
	temp_portc 	= PORTC;
	temp_portc 	&= mask_port_c; 
	temp_portd 	= PORTD;
	temp_portd 	&= mask_port_d; 
	temp_porte 	= PORTE;
	temp_porte 	&= mask_port_e;
}

void GetPort_OR(void) {
	temp_porta 	= PORTA;
	temp_porta 	|= (~mask_port_a); 
	temp_portb 	= PORTB;
	temp_portb 	|= (~mask_port_b); 
	temp_portc 	= PORTC;
	temp_portc 	|= (~mask_port_c); 
	temp_portd 	= PORTD;
	temp_portd 	|= (~mask_port_d); 
	temp_porte 	= PORTE;
	temp_porte 	|= (~mask_port_e); 
}





unsigned char TestExt(void) {


	// TEST EXTENSION PORT

	// Check for GND ======================================
	InitPort();

	GetPort_OR();

	if( ((temp_porta) != (0xFF)) ||  
		((temp_portb) != (0xFF)) ||  
		((temp_portc) != (0xFF)) ||  
		((temp_portd) != (0xFF)) ||  
		((temp_porte) != (0xFF)) )  return 1;


	// Check for VCC =============================
	// all as input
	InitPort();

	//pull up - output
	TRISA &= ~BIT2;
	//pull up - low
	PORTA &= ~BIT2;

	Delay(10);

	GetPort_AND();
 
	if( ((temp_porta) != (0x0)) ||
		((temp_portb) != (0x0)) ||
		((temp_portc) != (0x0)) ||
		((temp_portd) != (0x0)) ||
		((temp_porte) != (0x0)) ) return 2;



	// Running zero =========================================
	
	// Port A
	// all as input
	InitPort();
	// loop
	for(i=0; i<8; i++) {
	
		// this port is not tested
		if(!((mask_port_a)&(1<<i))) continue;
		
		TRISA = ~((1<<i)|BIT2);
		PORTA = ~(1<<i);

		Delay(10);

		GetPort_OR();

		// check for other zero at PortA
		if((temp_porta) != (0xFF&(~(1<<i)))) {
			return 3;
		} 

		// check for other zero at PortC
		if((temp_portc) != (0xFF)) {
			return 3;
		} 

		// check for other zero at PortD
		if((temp_portd) != (0xFF)) {
			return 3;
		} 

		// check for other zero at PortE
		if((temp_porte) != (0xFF)) {
			return 3;
		} 
		
	}

	// PortC
	// all as input
	InitPort();

	// loop
	for(i=0; i<8; i++) {
	
		// this port is not tested
		if(!((mask_port_c)&(1<<i))) continue;
	
		TRISC = ~(1<<i);
		PORTC = ~(1<<i);
		
		Delay(10);

		GetPort_OR();	
		
		// check for other zero at PortA
		if((temp_porta) != (0xFF)) {
			return 4;
		} 
	
		// check for other zero at PortC
		if((temp_portc) != (0xFF&(~(1<<i)))) {
			return 4;
		} 

		// check for other zero at PortB	 
		if((temp_portd) != (0xFF)) {
			return 4;
		} 
		
		// check for other zero at PortB	 
		if((temp_porte) != (0xFF)) {
			return 4;
		} 
	
	}


	// PortD
	// all as input
	InitPort();
	
	//loop
	for(i=0; i<8; i++) {
	
		// this port is not tested
		if(!((mask_port_d)&(1<<i))) continue;
	
		TRISD = ~(1<<i);
		PORTD = ~(1<<i);
		
		Delay(10);

		GetPort_OR();
	
		// check for other zero at PortA
		if((temp_porta) != (0xFF)) {
			return 5;
		} 
	
		// check for other zero at PortC
		if((temp_portc) != (0xFF)) {
			return 5;
		} 

		// check for other zero at PortB	 
		if((temp_portd) != (0xFF&(~(1<<i)))) {
			return 5;
		} 
		
		// check for other zero at PortB	 
		if((temp_porte) != (0xFF)) {
			return 5;
		} 	
	}


	// PortE
	// all as input
	InitPort();

	// loop
	for(i=0; i<8; i++) {
	
		// this port is not tested
		if(!((mask_port_e)&(1<<i))) continue;
	
		TRISE = ~(1<<i);
		PORTE = ~(1<<i);
		
		Delay(10);
	
		GetPort_OR();	

		// check for other zero at PortA 
		if((temp_porta) != (0xFF)) {
			return 6;
		} 

	
		// check for other zero at PortC
		if((temp_portc) != (0xFF)) {
			return 6;
		} 

		// check for other zero at PortD	 
		if((temp_portd) != (0xFF)) {
			return 6;
		} 
		
		// check for other zero at PortE	 
		if((temp_porte) != (0xFF&(~(1<<i)))) {
			return 6;
		} 
	
	}

	return 0;
}




