///////////                      LCD driver for pickit2   ////////////// 

#define LCD_RS  PORTEbits.RE0   // Register select   PORT E Pin 0
#define LCD_EN  PORTEbits.RE1    // Enable          PORT E Pin 1

#define LCD_A2  PORTAbits.RA2	// Data bits       PORT A
#define LCD_A3  PORTAbits.RA3	// Data bits       PORT A
#define LCD_A4  PORTAbits.RA4	// Data bits       PORT A
#define LCD_A5  PORTAbits.RA5	// Data bits       PORT A

void pulse(void) 
{
    LCD_EN = 1;
   // delay_ms(10);
    LCD_EN = 0;
  //  delay_ms(1);
}

void lcd_send_nibble( unsigned int n )
{


  //  delay_ms(5);
	if(n & 0x80) LCD_A5=1; else LCD_A5=0;
	if(n & 0x40) LCD_A4=1; else LCD_A4=0;
	if(n & 0x20) LCD_A3=1; else LCD_A3=0;
	if(n & 0x10) LCD_A2=1; else LCD_A2=0;
   // delay_ms(5);
    pulse();
}

void lcd_send_byte(unsigned int n)
{
	lcd_send_nibble((n & 0xf0));
//	delay_ms(1);
	lcd_send_nibble((n & 0x0f)<< 4);
//	delay_ms(1);	
}

void lcd_init_4bit(void) 
{
  //  delay_ms(50);
    LCD_RS = 0;				 //command mode
    lcd_send_nibble( 0x30 ); // eight bit mode
    lcd_send_nibble( 0x30 ); // eight bit mode
    lcd_send_nibble( 0x30 ); // eight bit mode
    lcd_send_nibble( 0x20 ); // four bit mode
   // delay_ms(5);
    lcd_send_byte(0x28);
    lcd_send_byte(0x17);
  //  delay_ms(5);
    lcd_send_byte(0x0C);//no blink, no underline
    //delay_ms(5);
	LCD_RS = 1;		//by default, I leave RS in text mode
}

void clr_lcd(void) 
{
	LCD_RS = 0;
	lcd_send_byte(0x01);
	LCD_RS = 1;		//by default, I leave RS in text mode
}

void display_add(unsigned int add) 
{
	LCD_RS = 0;
	lcd_send_byte(0x10 | add);
	LCD_RS = 1;		//by default, I leave RS in text mode
}

void text_string(char string1)
{
	lcd_send_byte(string1);
}
